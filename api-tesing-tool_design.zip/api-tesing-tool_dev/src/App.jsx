import PostmanPage from "./pages/PostmanPage";

const App = () => {
  return (
    <>
      {/* <MenuBar /> */}
      <PostmanPage />
    </>
  );
};

export default App;
