import {
  Button,
  Card,
  Col,
  Container,
  Form,
  Row,
  Tab,
  Tabs,
} from "react-bootstrap";

const App = () => {
  return (
    <Container>
      <h1 className='my-4 text-center'>React ReqBin</h1>
      <Form>
        <Row className='mb-3'>
          <Col md={8}>
            <Form.Control type='url' placeholder='https://example.com' />
          </Col>
          <Col md={2}>
            <Form.Select>
              <option value='GET'>GET</option>
              <option value='POST'>POST</option>
              <option value='PUT'>PUT</option>
              <option value='PATCH'>PATCH</option>
              <option value='DELETE'>DELETE</option>
              <option value='HEAD'>HEAD</option>
              <option value='OPTIONS'>OPTIONS</option>
            </Form.Select>
          </Col>
          <Col md={2}>
            <Button variant='primary'>Send</Button>
          </Col>
        </Row>
        <Tabs className='mb-3'>
          <Tab eventKey='content' title='Content'>
            <>
              <Form.Group className='mt-3'>
                <Form.Label>Content Type</Form.Label>
                <Form.Select>
                  <option value='FORM_URLENCODED'>
                    FORM URL Encoded (application/x-www-form-urlencoded)
                  </option>
                  <option value='JSON'>JSON (application/json)</option>
                  <option value='HTML'>HTML (text/html)</option>
                  <option value='XML'>XML (application/xml)</option>
                  <option value='TEXT'>TEXT (text/plain)</option>
                  <option value='CUSTOM'>CUSTOM</option>
                </Form.Select>
              </Form.Group>
              <Form.Group className='mt-3'>
                <Form.Label>Body</Form.Label>
                <Form.Control as='textarea' />
              </Form.Group>
            </>
          </Tab>
          <Tab eventKey='authorization' title='Authorization'>
            <Form.Group className='mt-3'>
              <Form.Check
                type='radio'
                name='authOption'
                id='noAuth'
                label='No Auth'
                value='noAuth'
              />
              <Form.Check
                type='radio'
                name='authOption'
                id='bearerToken'
                label='Bearer Token'
                value='bearerToken'
              />

              <Form.Group className='mt-3'>
                <Form.Label>Token</Form.Label>
                <Form.Control type='text' />
              </Form.Group>

              <Form.Check
                type='radio'
                name='authOption'
                id='basicAuth'
                label='Basic Auth'
                value='basicAuth'
              />

              <>
                <Form.Group className='mt-3'>
                  <Form.Label>Username</Form.Label>
                  <Form.Control type='text' />
                </Form.Group>
                <Form.Group className='mt-3'>
                  <Form.Label>Password</Form.Label>
                  <Form.Control type='password' />
                </Form.Group>
              </>

              <Form.Check
                type='radio'
                name='authOption'
                id='customAuth'
                label='Custom'
                value='customAuth'
              />

              <>
                <Form.Group className='mt-3'>
                  <Form.Label>Header</Form.Label>
                  <Form.Control type='text' />
                </Form.Group>
                <Form.Group className='mt-3'>
                  <Form.Label>Value</Form.Label>
                  <Form.Control type='text' />
                </Form.Group>
              </>
            </Form.Group>
          </Tab>
          <Tab eventKey='headers' title='Headers'>
            <Form.Group className='mt-3'>
              <Form.Label>Headers</Form.Label>
              <Form.Control
                as='textarea'
                rows={3}
                placeholder='{"Content-Type": "application/json"}'
              />
            </Form.Group>
          </Tab>
          <Tab eventKey='raw' title='Raw'>
            <Form.Group className='mt-3'>
              <Form.Label>Raw Request</Form.Label>
              <Form.Control as='textarea' rows={10} readOnly />
            </Form.Group>
          </Tab>
        </Tabs>
      </Form>
      <hr />
      <h5 className='d-flex mb-3 py-1'>
        <span className='text-muted'>Status:</span>
        <span className='ml-2' style={{ color: "#278800" }}>
          {status}
        </span>
        <span className='text-muted ml-3 ms-2'>Time:</span>
        <span className='ml-2' style={{ color: "#278800" }}>
          time
        </span>
        <span className='text-muted ml-3 ms-2'>Size:</span>
        <span className='ml-2' style={{ color: "#278800" }}>
          size
        </span>
      </h5>
      <Tabs className='mt-4'>
        <Tab eventKey='response' title='Response'>
          response
        </Tab>
        <Tab eventKey='headers' title='Headers'>
          response
        </Tab>
        <Tab eventKey='error' title='Error'>
          error
        </Tab>
        <Tab eventKey='raw' title='Raw'>
          <Card>
            <Card.Body>
              <pre>{JSON.stringify("our code", null, 2)}</pre>
            </Card.Body>
          </Card>
        </Tab>
      </Tabs>
    </Container>
  );
};

export default App;
