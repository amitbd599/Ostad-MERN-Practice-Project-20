import PostmanPage from "./pages/PostmanPage";

const App = () => {
  return (
    <>
      <PostmanPage />
    </>
  );
};

export default App;
