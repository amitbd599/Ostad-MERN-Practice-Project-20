const products = [
  {
    id: 1,
    title: "Clear Men Cooling Itch Control Anti-Dandruff Shampoo-650ml",
    price: "630",
    image:
      "http://www.subadmin.kistimath.com/storage/app/public/sOhBswsjXX26tNouqM6wZBVIzFKJn9RWPfQgOXSX.png",
    barcode: "1234567890123",
  },
  {
    id: 2,
    title: "Pantene Pro-v GoodBye Summer Frizz Shampoo-400 ml",
    price: "512",
    image:
      "http://subadmin.kistimath.com/storage/app/public/PMVlvVZj2QKb5bMeHGTQI2p2GETnAn62VlYOVi8o.jpeg",
    barcode: "1234567890124",
  },
  {
    id: 3,
    title: "Samsung 25W PD Super Fast Travel Charger USB-C",
    price: "1200",
    image:
      "http://www.subadmin.kistimath.com/storage/app/public/opDlLLictetKmtcEqlKgzDTwkaNn75XNRopf9DKV.png",
    barcode: "1234567890125",
  },
  {
    id: 4,
    title: "Vatika Olive And Henna Nourish Protect Shampoo -400ml",
    price: "450",
    image:
      "http://www.subadmin.kistimath.com/storage/app/public/v5fBcVO3NyzsXcrZslh2pXKWNFyozWLxsIO9rISk.png",
    barcode: "88H-0000UB-001",
  },
  {
    id: 5,
    title: "Garnier Men Power White Super Duo Foam 100 ml",
    price: "399",
    image:
      "http://www.subadmin.kistimath.com/storage/app/public/dmBaD5mWD8ffXkULS5DuSTqHPrRGDmKxxBnEBSBf.png",
    barcode: "8941100313466",
  },
];

export default products;
